'use strict';
angular.module('GenesisApp')
.controller('poblacionespecialctrl',['$scope','consultaHTTP','notification','cfpLoadingBar','$http',function($scope,consultaHTTP,notification,cfpLoadingBar,$http) {
   $( "#tabs" ).tabs();
}]);

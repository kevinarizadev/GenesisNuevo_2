'use strict';
angular.module('GenesisApp')
  .controller('ausentismoadminController', ['$scope', '$http', 'ngDialog', 'notification', 'ausentismoHttp', '$timeout', '$q', 'communication', '$controller', '$rootScope', '$window',
    function ($scope, $http, ngDialog, notification, ausentismoHttp, $timeout, $q, communication, $controller, $rootScope, $window) {
   
// alert("hola");

    }]);
